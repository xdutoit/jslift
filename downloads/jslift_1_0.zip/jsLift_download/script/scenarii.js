liste_scenarii = [
    // scenario 1
    {
        'description':'Dans ce premier scénario, vous devez créer une fonction <code>gererLiftInit()</code> qui sera appelée une fois au démarrage.',
        'nFloors':3,
        'nLifts':1,
        'spawnProbMatrix': [
            [0,.1,.1,.1],
            [.05,0,.01],
            [.05,.01,0],
        ],
    },
    // scenario 2
    {
        'description':'Dans ce second scénario, il peut être utile d\'améliorer votre code.',
        'nFloors':4,
        'nLifts':1,
        'spawnProbMatrix': [
            [0,.2,.2,.2,.2],
            [.1,0,.02,.02],
            [.1,.02,0,.02],
            [.1,.02,.02,0],
        ],
    },
    // scenario 3
    {
        'description':'Vous pouvez gérer ici plusieurs ascenseurs',
        'nFloors':5,
        'nLifts':3,
        'spawnProbFromGF': .2,
        'spawnProbToGF': .1,
        'spawnProbOther': .02,
    },
    // scenario 4
    {
        'description':'Et ici il faut être efficace',
        'nFloors':10,
        'nLifts':4,
        'spawnProbFromGF': .2,
        'spawnProbToGF': .1,
        'spawnProbOther': .02,
    },
];