let directions = [-1,-1,-1,-1];


function gererLiftInit(){
}

function gererLiftStep(){

}