function gererLiftInit(){
    liftSetDestinationList(0,[1,2,3,2,1,0],true);
}

function gererLiftStep(){
    updateLiftLights(0);
}

function liftIsAtFloor(l,f){
    console.log(`liftIsAtFloor(${l},${f})`)
}