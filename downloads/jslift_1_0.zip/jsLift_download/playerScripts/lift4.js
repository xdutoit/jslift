function gererLiftInit(){
    liftSetDestinationList(0,[0,4,0,0,0],true);
}

function liftArrivesAtFloor(l,f){
    if(f==2){
        console.log('forcer arrêt étage 2');
        liftGoTo(0,2); // OK !
        //liftAddDestinationAtStart(0,2); // OK !
    }
}