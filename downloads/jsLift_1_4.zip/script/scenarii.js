liste_scenarii = [
    // scenario 1
    {
        'description':'Dans ce premier scénario, vous devez créer une fonction <code>gererLiftInit()</code> qui sera appelée une fois au démarrage.<br>Il n\'y a pas encore beaucoup de passagers, donc faire le tour des étages en boucle devrait suffire.',
        'nFloors':3,
        'nLifts':1,
        'maxWaitingQueue': 10,
        'spawnProbMatrix': [
            [0,.1,.1],
            [.05,0,.01],
            [.05,.01,0],
        ],
        'challengeType':jsLift.CHALLENGE_NB_TRANSPORTED,
        'challengeData':15,
        'challengeMaxTime':60,
    },
    // scenario 2
    {
        'description':'Dans ce second scénario, il faudra utiliser les deux ascenseurs pour être efficace.',
        'nFloors':4,
        'nLifts':2,
        'maxWaitingQueue': 10,
        'spawnProbMatrix': [
            [0,.2,.2,.2,.2],
            [.1,0,.02,.02],
            [.1,.02,0,.02],
            [.1,.02,.02,0],
        ],
        'challengeType':jsLift.CHALLENGE_NB_TRANSPORTED,
        'challengeData':30,
        'challengeMaxTime':60,
    },
    // scenario 3
    {
        'description':'Les personnes arrivent une par une et il faut essayer de ne pas les faire trop attendre.',
        'nFloors':10,
        'nLifts':1,
        'maxTotalPeople': 1,
        'spawnProbFromGF': 0,
        'spawnProbToGF': 0,
        'spawnProbOther': 1,
        'challengeType':jsLift.CHALLENGE_MAX_WAITING_TIME,
        'challengeData':20,
        'challengeMaxTime':120,
    },
    // scenario 4
    {
        'description':'Et ici il faut être efficace',
        'nFloors':10,
        'nLifts':4,
        'spawnProbFromGF': .2,
        'spawnProbToGF': .1,
        'spawnProbOther': .02,
    },
];