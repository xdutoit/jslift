window.onload = function () {
    // fonction appelée au chargement de la page
    jsLift.init();
    jsLift.loadScenario();
};